s1c?  - schema 1 compliant XML
s1nc? - schema 1 non-compliant XML
s2c?  - schema 1 compliant XML
s2nc? - schema 1 non-compliant XML